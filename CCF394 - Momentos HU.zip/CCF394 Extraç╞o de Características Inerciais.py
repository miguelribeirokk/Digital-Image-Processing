# Livro VISÃO COMPUTACIONAL EM PYTHON - FERNANDO FELTRIN https://www.amazon.com.br/dp/B08NTW8TNV

import cv2
import numpy as np

imagem = cv2.imread('pneu.png', 0)

min_area = 500
colours = [(255, 0, 0), (0, 255, 0), (0, 0, 255)]  # Exemplo de cores

ret, thresh = cv2.threshold(imagem, 170, 255, 0)
cv2.imshow("Segmentada", thresh)
cv2.waitKey(0)

kernel = np.ones((5, 5), np.uint8) 
  
# Using cv2.erode() method  
thresh = cv2.erode(thresh, kernel)
cv2.imshow("Segmentada", thresh)
cv2.waitKey(0)

contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
c=0
for cnt in contours:
    if cv2.contourArea(cnt) > min_area:
        x, y, w, h = cv2.boundingRect(cnt)
        cropped_img = imagem[y:y + h, x:x + w]
        cv2.putText(cropped_img, f'c = {c}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.imwrite(f"contour_coloured_{c}.png", cropped_img)
        cv2.rectangle(imagem, (x, y), (x + w, y + h), colours[1], 2)
        c += 1

cv2.imshow("Saída", imagem)
cv2.waitKey(0)
cv2.destroyAllWindows()


momentos = cv2.moments(imagem)

print(f'Numero de momentos = {len(momentos)}')
#print(momentos)

area = momentos['m00']

print(f'Área = {area}')

mediaX = momentos['m10'] / area
mediaY = momentos['m01'] / area

print(f'Centro X ={mediaX}')
print(f'Centro Y ={mediaY}')

centroideX = int(momentos['m10'] / momentos['m00'])
centroideY = int(momentos['m01'] / momentos['m00'])

print(f'Centroide X ={centroideX}')
print(f'Centroide Y ={centroideY}')

# Momentos invariantes de Hu

momentosHu = cv2.HuMoments(momentos)

print(momentosHu.flatten())

