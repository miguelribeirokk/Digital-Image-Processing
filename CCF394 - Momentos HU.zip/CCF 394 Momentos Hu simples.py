import cv2
import numpy as np
import math
import csv

# Carregar a imagem e convertê-la para escala de cinza
img = cv2.imread('shape.png')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
ret, thresh = cv2.threshold(gray, 170, 255, 0)
contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
print("Number of contours detected:", len(contours))

# Preparar os dados para o CSV
num_contours = len(contours)
header = ['HuMomentIndex'] + [f'Contour {i + 1}' for i in range(num_contours)]
data = [[] for _ in range(7)]

# Computar os HuMoments para todos os contornos detectados na imagem
for i, cnt in enumerate(contours):
    x, y = cnt[0, 0]
    moments = cv2.moments(cnt)
    hm = cv2.HuMoments(moments)
    
    for j in range(0, 7):
        hm[j] = -1 * math.copysign(1.0, hm[j]) * math.log(abs(hm[j]))
        if len(data[j]) == 0:
            data[j].append(j + 1)  # Adicionar o índice do momento de Hu
        data[j].append(f"{hm[j][0]:.3f}")  # Adicionar o valor do momento de Hu formatado com 3 casas decimais

    cv2.drawContours(img, [cnt], -1, (0, 255, 255), 3)
    cv2.putText(img, f'Contour {i + 1}', (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
    print(f"\nHuMoments for Contour {i + 1}:\n", hm)

# Salvar os resultados em um arquivo CSV
with open('resultado.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(header)
    writer.writerows(data)

cv2.imshow("Hu-Moments", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
